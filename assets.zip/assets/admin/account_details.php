<?php
require_once '../includes/auth.php';
requireAdmin();

if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$userId = $_GET['id'];

// Get user details
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user) {
    redirectWithError('dashboard.php', 'User not found');
}

// Get user actions
$stmt = $pdo->prepare("SELECT * FROM user_actions WHERE user_id = ? ORDER BY action_at DESC");
$stmt->execute([$userId]);
$actions = $stmt->fetchAll();

// Get asset history for this user
$stmt = $pdo->prepare("SELECT ah.*, a.name as asset_name FROM asset_history ah 
                      JOIN assets a ON ah.asset_id = a.id 
                      WHERE ah.action_by = ? ORDER BY ah.action_at DESC");
$stmt->execute([$userId]);
$assetHistory = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_account'])) {
        $email = sanitizeInput($_POST['email']);
        $password = $_POST['password'];
        $role = $_POST['role'];
        
        if (!empty($password)) {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET email = ?, password = ?, role = ? WHERE id = ?");
            $stmt->execute([$email, $hashedPassword, $role, $userId]);
        } else {
            $stmt = $pdo->prepare("UPDATE users SET email = ?, role = ? WHERE id = ?");
            $stmt->execute([$email, $role, $userId]);
        }
        
        logUserAction($_SESSION['user_id'], 'update_account', "Updated account for user ID $userId");
        redirectWithSuccess('account_details.php?id='.$userId, 'Account updated successfully');
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Account Details</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <h1>Account Details: <?php echo htmlspecialchars($user['username']); ?></h1>
        <nav>
            <a href="dashboard.php">Back to Dashboard</a>
            <a href="../logout.php">Logout</a>
        </nav>
    </header>
    
    <main>
        <section class="account-details">
            <h2>Account Information</h2>
            <form method="POST">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="password">New Password (leave blank to keep current):</label>
                    <input type="password" id="password" name="password">
                </div>
                <div class="form-group">
                    <label for="role">Role:</label>
                    <select id="role" name="role" required>
                        <option value="admin" <?php echo $user['role'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
                        <option value="user" <?php echo $user['role'] === 'user' ? 'selected' : ''; ?>>User</option>
                    </select>
                </div>
                <button type="submit" name="update_account">Update Account</button>
            </form>
        </section>
        
        <section class="user-actions">
            <h2>User Actions</h2>
            <table>
                <thead>
                    <tr>
                        <th>Action</th>
                        <th>Details</th>
                        <th>Date/Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($actions as $action): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($action['action_type']); ?></td>
                        <td><?php echo htmlspecialchars($action['action_details']); ?></td>
                        <td><?php echo date('M d, Y H:i', strtotime($action['action_at'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
        
        <section class="asset-history">
            <h2>Asset History</h2>
            <table>
                <thead>
                    <tr>
                        <th>Asset</th>
                        <th>Action</th>
                        <th>Details</th>
                        <th>Date/Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($assetHistory as $history): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($history['asset_name']); ?></td>
                        <td><?php echo htmlspecialchars($history['action']); ?></td>
                        <td><?php echo htmlspecialchars($history['details']); ?></td>
                        <td><?php echo date('M d, Y H:i', strtotime($history['action_at'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </main>
    
    <script src="../js/main.js"></script>
</body>
</html>