<?php
require_once '../includes/auth.php';
requireAdmin();

// Determine which view to show
$show = $_GET['show'] ?? 'active';
$activeStatus = $show === 'deactivated' ? 'FALSE' : 'TRUE';

// Get users
$stmt = $pdo->prepare("SELECT id, username, email, role, created_at 
                      FROM users 
                      WHERE is_active = $activeStatus
                      ORDER BY username");
$stmt->execute();
$users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <h1>Admin Dashboard</h1>
        <nav>
            <a href="dashboard.php" class="<?= $show === 'active' ? 'active' : '' ?>">Active Accounts</a>
            <a href="dashboard.php?show=deactivated" class="<?= $show === 'deactivated' ? 'active' : '' ?>">Deactivated Accounts</a>
            <a href="manage_accounts.php?action=add">Add Account</a>
            <a href="../logout.php">Logout</a>
        </nav>
    </header>
    
    <main>
        <?php if (isset($_SESSION['success'])): ?>
            <div class="success"><?= $_SESSION['success'] ?></div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="error"><?= $_SESSION['error'] ?></div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        
        <section class="user-list">
            <h2><?= $show === 'active' ? 'Active' : 'Deactivated' ?> Accounts</h2>
            <table>
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th><?= $show === 'active' ? 'Created' : 'Deactivated' ?> On</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr class="<?= $show === 'deactivated' ? 'deactivated' : '' ?>">
                        <td><?= htmlspecialchars($user['username']) ?></td>
                        <td><?= htmlspecialchars($user['email']) ?></td>
                        <td><?= ucfirst($user['role']) ?></td>
                        <td><?= date('M d, Y', strtotime($user['created_at'])) ?></td>
                        <td>
                            <?php if ($show === 'active'): ?>
                                <a href="account_details.php?id=<?= $user['id'] ?>">View</a>
                                <a href="manage_accounts.php?action=delete&id=<?= $user['id'] ?>" 
                                   class="delete-btn">Deactivate</a>
                            <?php else: ?>
                                <a href="reactivate_account.php?id=<?= $user['id'] ?>" 
                                   class="reactivate-btn">Reactivate</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </main>
    
    <script src="../js/main.js"></script>
</body>
</html>