<?php
require_once '../includes/auth.php';
requireAdmin();

$action = $_GET['action'] ?? '';
$userId = $_GET['id'] ?? 0;

if ($action === 'delete' && $userId) {
    try {
        // Prevent deactivating last admin
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = 'admin' AND is_active = TRUE AND id != ?");
        $stmt->execute([$userId]);
        $adminCount = $stmt->fetchColumn();
        
        if ($adminCount < 1) {
            $_SESSION['error'] = 'Cannot deactivate the last active admin account';
            header("Location: dashboard.php");
            exit();
        }
        
        // Begin transaction
        $pdo->beginTransaction();
        
        // Deactivate user
        $stmt = $pdo->prepare("UPDATE users SET is_active = FALSE WHERE id = ?");
        $stmt->execute([$userId]);
        
        // Deactivate user's assets
        $stmt = $pdo->prepare("UPDATE assets SET is_active = FALSE WHERE added_by = ?");
        $stmt->execute([$userId]);
        
        // Log the action
        logUserAction($_SESSION['user_id'], 'deactivate_user', "Deactivated user ID $userId");
        
        // Commit transaction
        $pdo->commit();
        
        $_SESSION['success'] = 'User account deactivated successfully';
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Deactivation error: " . $e->getMessage());
        $_SESSION['error'] = 'Error deactivating user account';
    }
    
    header("Location: dashboard.php");
    exit();
}

?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo ucfirst($action); ?> Account</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <h1><?php echo ucfirst($action); ?> Account</h1>
        <nav>
            <a href="dashboard.php">Back to Dashboard</a>
            <a href="../logout.php">Logout</a>
        </nav>
    </header>
    
    <main>
        <?php if (isset($_SESSION['error'])): ?>
            <div class="error"><?php echo $_SESSION['error']; ?></div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        
        <section class="account-form">
            <form method="POST">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <div class="form-group">
                    <label for="role">Role:</label>
                    <select id="role" name="role" required>
                        <option value="admin">Admin</option>
                        <option value="user" selected>User</option>
                    </select>
                </div>
                <button type="submit">Create Account</button>
            </form>
        </section>
    </main>
    
    <script src="../js/main.js"></script>
</body>
</html>