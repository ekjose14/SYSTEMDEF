<?php
require_once '../includes/auth.php';
requireAdmin();

if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$userId = $_GET['id'];

try {
    // Begin transaction
    $pdo->beginTransaction();
    
    // Reactivate user
    $stmt = $pdo->prepare("UPDATE users SET is_active = TRUE WHERE id = ?");
    $stmt->execute([$userId]);
    
    // Reactivate user's assets
    $stmt = $pdo->prepare("UPDATE assets SET is_active = TRUE WHERE added_by = ?");
    $stmt->execute([$userId]);
    
    // Log the action
    logUserAction($_SESSION['user_id'], 'reactivate_user', "Reactivated user ID $userId");
    
    // Commit transaction
    $pdo->commit();
    
    $_SESSION['success'] = 'User account reactivated successfully';
    
} catch (PDOException $e) {
    $pdo->rollBack();
    error_log("Reactivation error: " . $e->getMessage());
    $_SESSION['error'] = 'Error reactivating user account';
}

header("Location: dashboard.php");
exit();
?>