<?php
session_start();
require_once 'db_connect.php';
require_once 'functions.php';

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Verify account is still active
$stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user || !$user['is_active']) {
    session_unset();
    session_destroy();
    header("Location: ../login.php?error=inactive");
    exit();
}

function requireAdmin() {
    global $pdo;
    
    // Verify user is admin and active
    $stmt = $pdo->prepare("SELECT role FROM users WHERE id = ? AND is_active = TRUE");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    
    if (!$user || $user['role'] !== 'admin') {
        header("Location: ../user/dashboard.php");
        exit();
    }
}
?>