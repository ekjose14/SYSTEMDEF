<?php
function sanitizeInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function logUserAction($userId, $actionType, $details) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO user_actions (user_id, action_type, action_details) VALUES (?, ?, ?)");
    $stmt->execute([$userId, $actionType, $details]);
}

function logAssetAction($assetId, $action, $userId, $details) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO asset_history (asset_id, action, action_by, details) VALUES (?, ?, ?, ?)");
    $stmt->execute([$assetId, $action, $userId, $details]);
}

function redirectWithError($url, $error) {
    $_SESSION['error'] = $error;
    header("Location: $url");
    exit();
}

function redirectWithSuccess($url, $message) {
    $_SESSION['success'] = $message;
    header("Location: $url");
    exit();
}
?>