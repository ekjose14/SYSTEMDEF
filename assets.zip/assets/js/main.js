// Search functionality
function searchAssets() {
    const input = document.getElementById('searchInput');
    const filter = input.value.toUpperCase();
    const table = document.getElementById('assetsTable');
    const tr = table.getElementsByTagName('tr');

    for (let i = 1; i < tr.length; i++) {
        let found = false;
        const td = tr[i].getElementsByTagName('td');
        
        for (let j = 0; j < td.length - 1; j++) {
            if (td[j]) {
                const txtValue = td[j].textContent || td[j].innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    found = true;
                    break;
                }
            }
        }
        
        tr[i].style.display = found ? '' : 'none';
    }
}

// Add event listener for Enter key
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('keyup', function(event) {
            if (event.key === 'Enter') {
                searchAssets();
            }
        });
    }

    // Auto-focus first input in forms
    const forms = document.getElementsByTagName('form');
    for (let form of forms) {
        const inputs = form.getElementsByTagName('input');
        if (inputs.length > 0) {
            inputs[0].focus();
        }
    }

    // Confirm before delete actions
    const deleteLinks = document.querySelectorAll('a[onclick*="confirm"]');
    for (let link of deleteLinks) {
        link.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to delete this?')) {
                e.preventDefault();
            }
        });
    }
});

// Date picker defaults
document.addEventListener('DOMContentLoaded', function() {
    const dateInputs = document.querySelectorAll('input[type="date"]');
    const today = new Date().toISOString().split('T')[0];
    
    for (let input of dateInputs) {
        if (!input.value) {
            input.value = today;
        }
    }
	document.addEventListener('DOMContentLoaded', function() {
    // Confirm account deactivation
    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to deactivate this account?\n\nThe user will lose access but all their data will be preserved.')) {
                e.preventDefault();
            }
        });
    });
    
    // Confirm account reactivation
    document.querySelectorAll('.reactivate-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            if (!confirm('Reactivate this account?\n\nThe user will regain access to the system.')) {
                e.preventDefault();
            }
        });
    });
});
});