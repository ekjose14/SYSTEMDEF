<?php
session_start();
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

if (isset($_SESSION['user_id'])) {
    logUserAction($_SESSION['user_id'], 'logout', 'User logged out');
}

session_unset();
session_destroy();
header("Location: login.php");
exit();
?>