<?php
require_once '../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitizeInput($_POST['name']);
    $category = sanitizeInput($_POST['category']);
    $date_acquired = $_POST['date_acquired'];
    $assigned_to = sanitizeInput($_POST['assigned_to']);
    
    $stmt = $pdo->prepare("INSERT INTO assets (name, category, date_acquired, assigned_to, added_by) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$name, $category, $date_acquired, $assigned_to, $_SESSION['user_id']]);
    
    $assetId = $pdo->lastInsertId();
    logAssetAction($assetId, 'added', $_SESSION['user_id'], "Asset $name added");
    logUserAction($_SESSION['user_id'], 'add_asset', "Added asset: $name");
    
    redirectWithSuccess('dashboard.php', 'Asset added successfully');
}

// Get distinct categories for suggestions
$stmt = $pdo->prepare("SELECT DISTINCT category FROM assets WHERE added_by = ?");
$stmt->execute([$_SESSION['user_id']]);
$categories = $stmt->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Asset</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <h1>Add New Asset</h1>
        <nav>
            <a href="dashboard.php">Back to Dashboard</a>
            <a href="../logout.php">Logout</a>
        </nav>
    </header>
    
    <main>
        <section class="asset-form">
            <form method="POST">
                <div class="form-group">
                    <label for="name">Asset Name:</label>
                    <input type="text" id="name" name="name" required>
                </div>
                
                <div class="form-group">
                    <label for="category">Category:</label>
                    <input type="text" id="category" name="category" list="categories" required>
                    <datalist id="categories">
                        <?php foreach ($categories as $category): ?>
                            <option value="<?php echo htmlspecialchars($category); ?>">
                        <?php endforeach; ?>
                    </datalist>
                </div>
                
                <div class="form-group">
                    <label for="date_acquired">Date Acquired:</label>
                    <input type="date" id="date_acquired" name="date_acquired" required>
                </div>
                
                <div class="form-group">
                    <label for="assigned_to">Assigned To:</label>
                    <input type="text" id="assigned_to" name="assigned_to" required>
                </div>
                
                <button type="submit">Add Asset</button>
            </form>
        </section>
    </main>
</body>
</html>