<?php
require_once '../includes/auth.php';

$search = $_GET['search'] ?? '';
$categoryFilter = $_GET['category'] ?? '';

// Base query
$query = "SELECT * FROM assets WHERE added_by = ? AND is_active = TRUE";
$params = [$_SESSION['user_id']];

// Add search filter
if (!empty($search)) {
    $query .= " AND (name LIKE ? OR assigned_to LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

// Add category filter
if (!empty($categoryFilter)) {
    $query .= " AND category = ?";
    $params[] = $categoryFilter;
}

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$assets = $stmt->fetchAll();

// Get distinct categories for filter
$stmt = $pdo->prepare("SELECT DISTINCT category FROM assets WHERE added_by = ?");
$stmt->execute([$_SESSION['user_id']]);
$categories = $stmt->fetchAll(PDO::FETCH_COLUMN);

$success = $_SESSION['success'] ?? null;
$error = $_SESSION['error'] ?? null;
unset($_SESSION['success'], $_SESSION['error']);

?>

<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <h1>Asset Management Dashboard</h1>
        <nav>
            <a href="dashboard.php">My Assets</a>
            <a href="add_asset.php">Add Asset</a>
            <a href="../logout.php">Logout</a>
        </nav>
    </header>
    
    <main>
        <?php if ($success): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <section class="asset-list">
            <h2>My Assets</h2>
            
            <div class="filters">
                <form method="GET" class="search-form">
                    <input type="text" name="search" placeholder="Search assets..." value="<?php echo htmlspecialchars($search); ?>">
                    <select name="category">
                        <option value="">All Categories</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?php echo htmlspecialchars($category); ?>" <?php echo $category === $categoryFilter ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($category); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit">Filter</button>
                    <a href="dashboard.php" class="button">Reset</a>
                </form>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Date Acquired</th>
                        <th>Assigned To</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($assets)): ?>
                        <tr>
                            <td colspan="5">No assets found</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($assets as $asset): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($asset['name']); ?></td>
                            <td><?php echo htmlspecialchars($asset['category']); ?></td>
                            <td><?php echo date('M d, Y', strtotime($asset['date_acquired'])); ?></td>
                            <td><?php echo htmlspecialchars($asset['assigned_to']); ?></td>
                            <td>
                                <a href="edit_asset.php?id=<?php echo $asset['id']; ?>">Edit</a>
                                <a href="delete_asset.php?id=<?php echo $asset['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>
    </main>
    
    <script src="../js/main.js"></script>
</body>
</html>