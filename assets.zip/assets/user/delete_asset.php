<?php
require_once '../includes/auth.php';

if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$assetId = $_GET['id'];

// Verify the asset belongs to the current user
$stmt = $pdo->prepare("SELECT * FROM assets WHERE id = ? AND added_by = ?");
$stmt->execute([$assetId, $_SESSION['user_id']]);
$asset = $stmt->fetch();

if (!$asset) {
    redirectWithError('dashboard.php', 'Asset not found or access denied');
}

// Soft delete the asset
$stmt = $pdo->prepare("UPDATE assets SET is_active = FALSE WHERE id = ?");
$stmt->execute([$assetId]);

logAssetAction($assetId, 'deleted', $_SESSION['user_id'], "Asset deleted");
logUserAction($_SESSION['user_id'], 'delete_asset', "Deleted asset ID $assetId");

redirectWithSuccess('dashboard.php', 'Asset deleted successfully');
?>