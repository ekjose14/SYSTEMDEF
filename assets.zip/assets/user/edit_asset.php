<?php
require_once '../includes/auth.php';

if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$assetId = $_GET['id'];

// Verify the asset belongs to the current user
$stmt = $pdo->prepare("SELECT * FROM assets WHERE id = ? AND added_by = ?");
$stmt->execute([$assetId, $_SESSION['user_id']]);
$asset = $stmt->fetch();

if (!$asset) {
    redirectWithError('dashboard.php', 'Asset not found or access denied');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitizeInput($_POST['name']);
    $category = sanitizeInput($_POST['category']);
    $date_acquired = $_POST['date_acquired'];
    $assigned_to = sanitizeInput($_POST['assigned_to']);
    
    $stmt = $pdo->prepare("UPDATE assets SET name = ?, category = ?, date_acquired = ?, assigned_to = ? WHERE id = ?");
    $stmt->execute([$name, $category, $date_acquired, $assigned_to, $assetId]);
    
    logAssetAction($assetId, 'modified', $_SESSION['user_id'], "Asset updated");
    logUserAction($_SESSION['user_id'], 'update_asset', "Updated asset ID $assetId");
    
    redirectWithSuccess('dashboard.php', 'Asset updated successfully');
}

// Get distinct categories for suggestions
$stmt = $pdo->prepare("SELECT DISTINCT category FROM assets WHERE added_by = ?");
$stmt->execute([$_SESSION['user_id']]);
$categories = $stmt->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Asset</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <h1>Edit Asset</h1>
        <nav>
            <a href="dashboard.php">Back to Dashboard</a>
            <a href="../logout.php">Logout</a>
        </nav>
    </header>
    
    <main>
        <section class="asset-form">
            <form method="POST">
                <div class="form-group">
                    <label for="name">Asset Name:</label>
                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($asset['name']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="category">Category:</label>
                    <input type="text" id="category" name="category" list="categories" value="<?php echo htmlspecialchars($asset['category']); ?>" required>
                    <datalist id="categories">
                        <?php foreach ($categories as $category): ?>
                            <option value="<?php echo htmlspecialchars($category); ?>">
                        <?php endforeach; ?>
                    </datalist>
                </div>
                
                <div class="form-group">
                    <label for="date_acquired">Date Acquired:</label>
                    <input type="date" id="date_acquired" name="date_acquired" value="<?php echo htmlspecialchars($asset['date_acquired']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="assigned_to">Assigned To:</label>
                    <input type="text" id="assigned_to" name="assigned_to" value="<?php echo htmlspecialchars($asset['assigned_to']); ?>" required>
                </div>
                
                <button type="submit">Update Asset</button>
            </form>
        </section>
    </main>
</body>
</html>