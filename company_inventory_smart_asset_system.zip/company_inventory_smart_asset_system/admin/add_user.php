<?php
include "../config.php";
session_start();
if ($_SESSION['role'] !== 'admin') die("Access denied.");

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = md5($_POST['password']);
    $role = $_POST['role'];

    // Check if username already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $error = "Error: Username already exists.";
    } else {
        $stmtInsert = $conn->prepare("INSERT INTO users (username, password, role, status) VALUES (?, ?, ?, 'active')");
        $stmtInsert->bind_param("sss", $username, $password, $role);
        $stmtInsert->execute();
        header("Location: view_users.php");
        exit;
    }

    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add User</title>
    <style>
        /* Base Reset & Layout */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #1a1a1a, #2c2c2c, #3d3d3d);
            color: #eee;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            animation: fadeIn 0.8s ease-in;
            overflow: hidden;
        }

        .container {
            background: rgba(70, 70, 70, 0.85);
            padding: 40px 50px;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(255, 102, 0, 0.35);
            max-width: 460px;
            width: 90%;
            animation: popIn 0.6s ease-in-out;
            text-align: center;
            backdrop-filter: saturate(180%) blur(12px);
        }

        h2 {
            margin-bottom: 30px;
            font-size: 32px;
            font-weight: 800;
            color: #ff6600;
            text-shadow: 0 0 8px #ff6600;
        }

        .error {
            color: #ff4d4d;
            font-size: 16px;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        input[type="text"],
        input[type="password"],
        select {
            padding: 14px;
            font-size: 16px;
            border-radius: 12px;
            border: 2px solid #555;
            background: #222;
            color: #eee;
            transition: border-color 0.3s ease, box-shadow 0.3s ease, background-color 0.3s ease;
        }

        input::placeholder {
            color: #999;
            font-style: italic;
        }

        input:focus,
        select:focus {
            border-color: #ff6600;
            outline: none;
            box-shadow: 0 0 10px #ff6600;
            background-color: #333;
        }

        button {
            padding: 16px;
            font-size: 18px;
            background: transparent;
            border: 2px solid #eee;
            border-radius: 12px;
            color: #eee;
            font-weight: 600;
            letter-spacing: 0.05em;
            cursor: pointer;
            transition:
                background-color 0.4s ease,
                color 0.4s ease,
                box-shadow 0.3s ease,
                transform 0.3s ease;
        }

        button:hover {
            background-color: #ff6600;
            color: #fff;
            font-weight: 700;
            box-shadow: 0 0 10px #ff6600, 0 0 20px #ff6600;
            transform: translateY(-3px);
        }

        .nav-button {
            display: inline-block;
            margin-top: 28px;
            background: transparent;
            border: 2px solid #eee;
            color: #eee;
            padding: 14px 36px;
            font-size: 18px;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            transition:
                background-color 0.4s ease,
                color 0.4s ease,
                box-shadow 0.3s ease,
                transform 0.3s ease;
        }

        .nav-button:hover {
            background-color: #ff6600;
            color: #fff;
            box-shadow: 0 0 10px #ff6600, 0 0 20px #ff6600;
            transform: translateY(-3px);
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes popIn {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Add User</h2>
        <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input name="password" type="password" placeholder="Password" required>
            <select name="role" required>
                <option value="">Select Role</option>
                <option value="admin">Admin</option>
                <option value="user">User</option>
            </select>
            <button type="submit">Add User</button>
        </form>
        <a href="view_users.php" class="nav-button">Back</a>
    </div>
</body>
</html>
