<?php
include "../config.php";
session_start();
if ($_SESSION['role'] !== 'admin') die("Access denied.");

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = md5($_POST['password']);
    $role = $_POST['role'];

    // Check if username already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $error = "Error: Username already exists.";
    } else {
        $stmtInsert = $conn->prepare("INSERT INTO users (username, password, role, status) VALUES (?, ?, ?, 'active')");
        $stmtInsert->bind_param("sss", $username, $password, $role);
        $stmtInsert->execute();
        header("Location: view_users.php");
        exit;
    }

    $stmt->close();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add User</title>
    
    <style>
    body {
        font-family: 'Segoe UI', sans-serif;
        margin: 0;
        padding: 0;
        background: #f4f7f9;
        color: #2c3e50;
    }

    .container {
        max-width: 600px; /* Increased width */
        margin: 50px auto;
        background: #fff;
        padding: 50px; /* Increased padding */
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        animation: slideUp 0.4s ease-out;
    }

    h2 {
        text-align: center;
        margin-bottom: 30px; /* Increased margin */
        color: #3498db;
        font-size: 36px; /* Increased font size */
    }

    form {
        display: flex;
        flex-direction: column;
        gap: 25px; /* Increased gap between form elements */
    }

    input[type="text"], input[type="password"], select {
        padding: 14px; /* Increased padding */
        font-size: 18px; /* Increased font size */
        border-radius: 8px; /* More rounded edges */
        border: 1px solid #ccc;
        width: 100%;
        box-sizing: border-box;
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }

    input:hover, select:hover {
        border-color: #3498db;
    }

    input:focus, select:focus {
        border-color: #3498db;
        outline: none;
        box-shadow: 0 0 5px rgba(52, 152, 219, 0.4);
    }

    button {
        padding: 14px; /* Increased padding */
        background-color: #3498db;
        color: white;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 18px; /* Increased font size */
        transition: background-color 0.3s ease;
    }

    button:hover {
        background-color: #2980b9;
    }

    .error {
        color: red;
        font-size: 16px; /* Increased font size for error messages */
        text-align: center;
    }

    .nav-button {
        display: block;
        background-color: #3498db;
        color: white;
        padding: 14px; /* Increased padding */
        text-align: center;
        text-decoration: none;
        border-radius: 8px;
        font-size: 18px; /* Increased font size */
        transition: background-color 0.3s ease;
        margin-top: 25px; /* Increased margin-top */
    }

    .nav-button:hover {
        background-color: #2980b9;
    }

    @keyframes slideUp {
        from { transform: translateY(15px); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
    }
    </style>
</head>
<body>
    <div class="container">
        <h2>Add User</h2>
        <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input name="password" type="password" placeholder="Password" required>
            <select name="role" required>
                <option value="">Select Role</option>
                <option value="admin">Admin</option>
                <option value="user">User</option>
            </select>
            <button type="submit">Add User</button>
        </form>
        <a href="view_users.php" class="nav-button">Back</a>
    </div>
</body>
</html>
