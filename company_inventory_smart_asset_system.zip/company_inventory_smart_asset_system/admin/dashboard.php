<?php
session_start();
if ($_SESSION['role'] !== 'admin') die("Access denied.");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Admin Dashboard</title>
    <style>
        /* Reset & base */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body, html {
            height: 100%;
            background: linear-gradient(135deg, #1a1a1a, #2c2c2c, #3d3d3d);
            color: #eee;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            animation: fadeIn 0.8s ease-in;
        }
        .container {
            background: rgba(70, 70, 70, 0.85);
            padding: 48px 60px;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(255, 102, 0, 0.35);
            max-width: 600px;
            width: 90%;
            animation: popIn 0.6s ease-in-out;
            color: #eee;
            text-align: center;
            backdrop-filter: saturate(180%) blur(12px);
        }
        h2 {
            font-size: 36px;
            margin-bottom: 40px;
            color: #ff6600;
            font-weight: 800;
            animation: slideDown 0.6s ease-in-out;
            letter-spacing: 0.05em;
            text-shadow: 0 0 8px #ff6600;
        }
        nav {
            display: flex;
            flex-direction: column;
            gap: 24px;
            animation: popIn 0.6s ease-in-out;
        }
        .nav-button {
            background: transparent;
            border: 2px solid #eee;
            border-radius: 12px;
            color: #eee;
            padding: 20px 48px;
            font-size: 20px;
            cursor: pointer;
            text-decoration: none;
            text-align: center;
            transition:
                background-color 0.3s ease,
                color 0.3s ease,
                box-shadow 0.3s ease,
                transform 0.2s ease;
            user-select: none;
            display: inline-block;
            font-weight: 600;
            letter-spacing: 0.05em;
        }
        .nav-button:hover {
            background-color: #ff6600;
            color: #fff;
            font-weight: 700;
            transform: translateY(-3px);
            box-shadow: 0 0 10px #ff6600, 0 0 20px #ff6600;
        }
        .nav-button:focus {
            outline: none;
            box-shadow: 0 0 0 3px rgba(255, 102, 0, 0.5);
        }
        @media (min-width: 600px) {
            nav {
                flex-direction: row;
                justify-content: center;
                flex-wrap: wrap;
            }
            .nav-button {
                min-width: 160px;
            }
        }
        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slideDown {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        @keyframes popIn {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
    </style>
</head>
<body>
    <div class="container" role="main">
        <h2>Admin Dashboard</h2>
        <nav aria-label="Admin dashboard navigation">
            <a href="view_users.php" class="nav-button" role="button">Manage Users</a>
            <a href="view_history.php" class="nav-button" role="button">View Activity Logs</a>
            <a href="delete_requests.php" class="nav-button" role="button">Delete Requests</a>
            <a href="../logout.php" class="nav-button" role="button">Logout</a>
        </nav>
    </div>
</body>
</html>
