<?php
// admin/delete_requests.php (Admin Approval Panel)
include "../config.php";
session_start();
if ($_SESSION['role'] !== 'admin') die("Access denied.");

// Approve request
if (isset($_GET['approve'])) {
    $req_id = (int)$_GET['approve'];

    $stmt = $conn->prepare("SELECT r.*, a.quantity AS current_quantity FROM delete_requests r 
                            JOIN assets a ON r.asset_id = a.id WHERE r.id = ?");
    $stmt->bind_param("i", $req_id);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res && $res->num_rows === 1) {
        $data = $res->fetch_assoc();
        $new_qty = $data['current_quantity'] - $data['quantity'];

        if ($new_qty <= 0) {
            $delStmt = $conn->prepare("DELETE FROM assets WHERE id = ?");
            $delStmt->bind_param("i", $data['asset_id']);
            $delStmt->execute();
            $delStmt->close();
        } else {
            $updStmt = $conn->prepare("UPDATE assets SET quantity = ? WHERE id = ?");
            $updStmt->bind_param("ii", $new_qty, $data['asset_id']);
            $updStmt->execute();
            $updStmt->close();
        }

        $delReqStmt = $conn->prepare("DELETE FROM delete_requests WHERE id = ?");
        $delReqStmt->bind_param("i", $req_id);
        $delReqStmt->execute();
        $delReqStmt->close();
    }
    $stmt->close();

    header("Location: delete_requests.php");
    exit;
}

// Reject request
if (isset($_GET['reject'])) {
    $req_id = (int)$_GET['reject'];

    $delReqStmt = $conn->prepare("DELETE FROM delete_requests WHERE id = ?");
    $delReqStmt->bind_param("i", $req_id);
    $delReqStmt->execute();
    $delReqStmt->close();

    header("Location: delete_requests.php");
    exit;
}

$requests = $conn->query("SELECT r.*, u.username, a.name AS asset_name FROM delete_requests r
                          JOIN users u ON r.user_id = u.id
                          JOIN assets a ON r.asset_id = a.id
                          ORDER BY r.timestamp DESC");

if (!$requests) {
    die("Database query failed: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Asset Deletion Requests</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0; padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body, html {
            height: 100%;
            background: linear-gradient(135deg, #1a1a1a, #2c2c2c, #3d3d3d);
            color: #eee;
            padding: 40px 20px;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            animation: fadeIn 0.7s ease-in;
        }

        .container {
            background: rgba(70, 70, 70, 0.85);
            max-width: 900px;
            width: 100%;
            padding: 40px 30px;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(255, 102, 0, 0.35);
            backdrop-filter: saturate(180%) blur(12px);
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 36px;
            font-weight: 800;
            color: #ff6600;
            text-shadow: 0 0 10px #ff6600;
            user-select: none;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: #333;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: inset 0 0 20px rgba(255, 102, 0, 0.2);
        }

        th, td {
            padding: 16px 18px;
            text-align: left;
            font-size: 16px;
            color: #eee;
            text-shadow: 0 0 2px rgba(0, 0, 0, 0.6);
            border-bottom: 1px solid rgba(255,255,255,0.1);
            vertical-align: middle;
        }

        th {
            background-color: #444;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        tr:nth-child(even) {
            background-color: #2e2e2e;
        }

        tr:hover {
            background-color: rgba(255, 102, 0, 0.15);
            cursor: default;
            transition: background-color 0.3s ease;
        }

        a {
            color: #ff6600;
            font-weight: 600;
            text-decoration: none;
            user-select: none;
            transition: color 0.3s ease, text-shadow 0.3s ease;
        }

        a:hover {
            color: #ff9966;
            text-shadow: 0 0 6px #ff9966;
        }

        a.action-link {
            padding: 6px 14px;
            border: 2px solid #ff6600;
            border-radius: 12px;
            background: transparent;
            display: inline-block;
            margin: 0 6px;
            transition: 
                background-color 0.3s ease,
                color 0.3s ease,
                box-shadow 0.3s ease,
                transform 0.2s ease;
        }

        a.action-link:hover {
            background-color: #ff6600;
            color: #fff;
            box-shadow: 0 0 12px #ff6600, 0 0 24px #ff6600;
            transform: translateY(-3px);
        }

        .no-requests {
            text-align: center;
            font-size: 20px;
            color: #ccc;
            padding: 30px 0;
        }

        .back-link {
            display: inline-block;
            margin-top: 30px;
            padding: 14px 36px;
            border: 2px solid #eee;
            border-radius: 12px;
            color: #eee;
            font-weight: 600;
            text-decoration: none;
            user-select: none;
            transition:
                background-color 0.3s ease,
                color 0.3s ease,
                box-shadow 0.3s ease,
                transform 0.3s ease;
        }

        .back-link:hover {
            background-color: #ff6600;
            color: #fff;
            box-shadow: 0 0 12px #ff6600, 0 0 24px #ff6600;
            transform: translateY(-3px);
        }

        @keyframes fadeIn {
            from {opacity: 0;}
            to {opacity: 1;}
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Asset Deletion Requests</h2>
        <?php if ($requests->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Asset</th>
                    <th>User</th>
                    <th>Quantity</th>
                    <th>Reason</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $requests->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['asset_name']) ?></td>
                    <td><?= htmlspecialchars($row['username']) ?></td>
                    <td><?= (int)$row['quantity'] ?></td>
                    <td><?= htmlspecialchars($row['reason']) ?></td>
                    <td><?= htmlspecialchars($row['timestamp']) ?></td>
                    <td>
                        <a href="delete_requests.php?approve=<?= $row['id'] ?>"
                           onclick="return confirm('Approve this request?')"
                           class="action-link">Approve</a>
                        <a href="delete_requests.php?reject=<?= $row['id'] ?>"
                           onclick="return confirm('Reject this request?')"
                           class="action-link">Reject</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <?php else: ?>
            <p class="no-requests">No pending requests.</p>
        <?php endif; ?>

        <a href="dashboard.php" class="back-link">← Back to Dashboard</a>
    </div>
</body>
</html>
