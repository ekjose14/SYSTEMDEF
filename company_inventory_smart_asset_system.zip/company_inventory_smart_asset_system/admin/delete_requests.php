<?php
session_start();
include '../config.php';

// --- HANDLE APPROVE ---
if (isset($_GET['approve'])) {
    $request_id = $_GET['approve'];
    $admin_id = $_SESSION['user_id'];

    // Fetch delete request
    $stmt = $conn->prepare("SELECT * FROM delete_requests WHERE id = ?");
    $stmt->bind_param("i", $request_id);
    $stmt->execute();
    $request_result = $stmt->get_result();

    if ($request_result->num_rows > 0) {
        $request = $request_result->fetch_assoc();
        $item_id = $request['item_id'];
        $quantity = $request['quantity'];

        // Fetch item details
        $stmt = $conn->prepare("SELECT name, quantity FROM items WHERE id = ?");
        $stmt->bind_param("i", $item_id);
        $stmt->execute();
        $item_result = $stmt->get_result();

        if ($item_result->num_rows > 0) {
            $item = $item_result->fetch_assoc();
            $current_quantity = $item['quantity'];
            $new_quantity = $current_quantity - $quantity;

            // Prepare action description
            $action = "Deleted Item (Qty: $quantity)";

            // Log to history BEFORE any item deletion
            $stmt = $conn->prepare("INSERT INTO history (item_id, action, quantity, performed_by) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("isii", $item_id, $action, $quantity, $admin_id);
            $stmt->execute();

            // Update or delete item
            if ($new_quantity > 0) {
                $stmt = $conn->prepare("UPDATE items SET quantity = ? WHERE id = ?");
                $stmt->bind_param("ii", $new_quantity, $item_id);
                $stmt->execute();
            } else {
                $stmt = $conn->prepare("DELETE FROM items WHERE id = ?");
                $stmt->bind_param("i", $item_id);
                $stmt->execute();
            }

            // Delete the request
            $stmt = $conn->prepare("DELETE FROM delete_requests WHERE id = ?");
            $stmt->bind_param("i", $request_id);
            $stmt->execute();

            $_SESSION['success'] = "Delete request approved and item updated.";
        } else {
            $_SESSION['error'] = "Item not found.";
        }
    } else {
        $_SESSION['error'] = "Delete request not found.";
    }

    header("Location: delete_requests.php");
    exit();
}

// --- HANDLE REJECT ---
if (isset($_GET['reject'])) {
    $request_id = $_GET['reject'];

    $stmt = $conn->prepare("DELETE FROM delete_requests WHERE id = ?");
    $stmt->bind_param("i", $request_id);
    $stmt->execute();

    $_SESSION['success'] = "Delete request rejected.";
    header("Location: delete_requests.php");
    exit();
}

// --- FETCH REQUESTS ---
$query = "
    SELECT dr.id, dr.item_id, dr.quantity, dr.reason, dr.timestamp, 
           i.name AS asset_name, u.username
    FROM delete_requests dr
    JOIN items i ON dr.item_id = i.id
    JOIN users u ON dr.user_id = u.id
    ORDER BY dr.timestamp DESC
";

$requests = $conn->query($query);
if (!$requests) {
    die("Database query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Asset Deletion Requests</title>
    <style>
        /* [Your existing CSS remains unchanged] */
        * {
            box-sizing: border-box;
            margin: 0; padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body, html {
            height: 100%;
            background: linear-gradient(135deg, #1a1a1a, #2c2c2c, #3d3d3d);
            color: #eee;
            padding: 40px 20px;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            animation: fadeIn 0.7s ease-in;
        }

        .container {
            background: rgba(70, 70, 70, 0.85);
            max-width: 900px;
            width: 100%;
            padding: 40px 30px;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(255, 102, 0, 0.35);
            backdrop-filter: saturate(180%) blur(12px);
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 36px;
            font-weight: 800;
            color: #ff6600;
            text-shadow: 0 0 10px #ff6600;
            user-select: none;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: #333;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: inset 0 0 20px rgba(255, 102, 0, 0.2);
        }

        th, td {
            padding: 16px 18px;
            text-align: left;
            font-size: 16px;
            color: #eee;
            text-shadow: 0 0 2px rgba(0, 0, 0, 0.6);
            border-bottom: 1px solid rgba(255,255,255,0.1);
            vertical-align: middle;
        }

        th {
            background-color: #444;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        tr:nth-child(even) {
            background-color: #2e2e2e;
        }

        tr:hover {
            background-color: rgba(255, 102, 0, 0.15);
            cursor: default;
            transition: background-color 0.3s ease;
        }

        a {
            color: #ff6600;
            font-weight: 600;
            text-decoration: none;
            user-select: none;
            transition: color 0.3s ease, text-shadow 0.3s ease;
        }

        a:hover {
            color: #ff9966;
            text-shadow: 0 0 6px #ff9966;
        }

        a.action-link {
            padding: 6px 14px;
            border: 2px solid #ff6600;
            border-radius: 12px;
            background: transparent;
            display: inline-block;
            margin: 0 6px;
            transition: 
                background-color 0.3s ease,
                color 0.3s ease,
                box-shadow 0.3s ease,
                transform 0.2s ease;
        }

        a.action-link:hover {
            background-color: #ff6600;
            color: #fff;
            box-shadow: 0 0 12px #ff6600, 0 0 24px #ff6600;
            transform: translateY(-3px);
        }

        .no-requests {
            text-align: center;
            font-size: 20px;
            color: #ccc;
            padding: 30px 0;
        }

        .back-link {
            display: inline-block;
            margin-top: 30px;
            padding: 14px 36px;
            border: 2px solid #eee;
            border-radius: 12px;
            color: #eee;
            font-weight: 600;
            text-decoration: none;
            user-select: none;
            transition:
                background-color 0.3s ease,
                color 0.3s ease,
                box-shadow 0.3s ease,
                transform 0.3s ease;
        }

        .back-link:hover {
            background-color: #ff6600;
            color: #fff;
            box-shadow: 0 0 12px #ff6600, 0 0 24px #ff6600;
            transform: translateY(-3px);
        }

        @keyframes fadeIn {
            from {opacity: 0;}
            to {opacity: 1;}
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Asset Deletion Requests</h2>
        <?php if ($requests->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Item</th>
                    <th>User</th>
                    <th>Quantity</th>
                    <th>Reason</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $requests->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['asset_name']) ?></td>
                    <td><?= htmlspecialchars($row['username']) ?></td>
                    <td><?= (int)$row['quantity'] ?></td>
                    <td><?= htmlspecialchars($row['reason']) ?></td>
                    <td><?= htmlspecialchars($row['timestamp']) ?></td>
                    <td>
                        <a href="delete_requests.php?approve=<?= $row['id'] ?>"
                           onclick="return confirm('Approve this request?')"
                           class="action-link">Approve</a>
                        <a href="delete_requests.php?reject=<?= $row['id'] ?>"
                           onclick="return confirm('Reject this request?')"
                           class="action-link">Reject</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <?php else: ?>
            <p class="no-requests">No pending requests.</p>
        <?php endif; ?>

        <a href="dashboard.php" class="back-link">← Back to Dashboard</a>
    </div>
</body>
</html>
