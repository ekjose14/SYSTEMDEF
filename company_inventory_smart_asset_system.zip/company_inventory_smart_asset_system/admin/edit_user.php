<?php
include "../config.php";
session_start();
if ($_SESSION['role'] !== 'admin') die("Access denied.");

$id = $_GET['id'];
$user = $conn->query("SELECT * FROM users WHERE id=$id")->fetch_assoc();

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $role = $_POST['role'];
    $password = $_POST['password'];

    $check = $conn->query("SELECT id FROM users WHERE username='$username' AND id != $id");
    if ($check->num_rows > 0) {
        $error = "Error: Username already exists.";
    } elseif (($username === 'admin' && $role !== 'admin') || ($username === 'user' && $role !== 'user')) {
        $error = "Error: Username and role do not match. 'admin' must have role Admin, 'user' must have role User.";
    } else {
        $updateQuery = "UPDATE users SET username='$username', role='$role'";
        if (!empty($password)) {
            $hashedPassword = md5($password);
            $updateQuery .= ", password='$hashedPassword'";
        }
        $updateQuery .= " WHERE id=$id";
        $conn->query($updateQuery);

        header("Location: view_users.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Edit User</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #1a1a1a, #2c2c2c, #3d3d3d);
            color: #eee;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            padding: 20px;
            animation: fadeIn 0.5s ease;
        }

        .container {
            background: rgba(70, 70, 70, 0.85);
            padding: 50px;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(255, 102, 0, 0.35);
            width: 100%;
            max-width: 600px;
            animation: slideUp 0.5s ease-out;
            backdrop-filter: saturate(180%) blur(12px);
        }

        h2 {
            text-align: center;
            color: #ff6600;
            margin-bottom: 30px;
            font-size: 36px;
            text-shadow: 0 0 8px #ff6600;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 25px;
        }

        input[type="text"],
        input[type="password"],
        select {
            padding: 16px;
            font-size: 18px;
            border-radius: 12px;
            border: 2px solid #555;
            width: 100%;
            background: #222;
            color: #eee;
            transition: border-color 0.3s ease, background-color 0.3s ease, box-shadow 0.3s ease;
        }

        input::placeholder {
            color: #999;
            font-style: italic;
        }

        input:focus,
        select:focus {
            outline: none;
            border-color: #ff6600;
            background-color: #333;
            box-shadow: 0 0 10px #ff6600;
        }

        button {
            padding: 16px;
            background: transparent;
            border: 2px solid #eee;
            color: #eee;
            font-size: 18px;
            font-weight: 600;
            border-radius: 12px;
            cursor: pointer;
            letter-spacing: 0.05em;
            transition:
                background-color 0.3s ease,
                color 0.3s ease,
                box-shadow 0.3s ease,
                transform 0.3s ease;
        }

        button:hover {
            background-color: #ff6600;
            color: #fff;
            box-shadow: 0 0 10px #ff6600, 0 0 20px #ff6600;
            transform: translateY(-3px);
        }

        .nav-button {
            display: block;
            background: transparent;
            border: 2px solid #eee;
            color: #eee;
            text-align: center;
            text-decoration: none;
            padding: 14px 28px;
            font-size: 18px;
            border-radius: 12px;
            margin-top: 30px;
            font-weight: 600;
            transition:
                background-color 0.3s ease,
                color 0.3s ease,
                box-shadow 0.3s ease,
                transform 0.3s ease;
        }

        .nav-button:hover {
            background-color: #ff6600;
            color: #fff;
            box-shadow: 0 0 10px #ff6600, 0 0 20px #ff6600;
            transform: translateY(-3px);
        }

        .error {
            color: #ff4d4d;
            background: #4d0000;
            padding: 14px 18px;
            border-radius: 12px;
            border: 1px solid #ff8080;
            margin-bottom: 20px;
            text-align: center;
            font-size: 16px;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from { transform: translateY(15px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit User</h2>
        <?php if (!empty($error)) echo "<div class='error'>$error</div>"; ?>
        <form method="POST">
            <input name="username" type="text" value="<?= htmlspecialchars($user['username']) ?>" required>
            <select name="role" required>
                <option value="admin" <?= $user['role'] == 'admin' ? 'selected' : '' ?>>Admin</option>
                <option value="user" <?= $user['role'] == 'user' ? 'selected' : '' ?>>User</option>
            </select>
            <input name="password" type="password" placeholder="New Password (leave blank to keep current)">
            <button type="submit">Update</button>
        </form>
        <a href="view_users.php" class="nav-button">← Back to Users</a>
    </div>
</body>
</html>
