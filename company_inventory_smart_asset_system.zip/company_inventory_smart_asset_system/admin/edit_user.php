<?php
include "../config.php";
session_start();
if ($_SESSION['role'] !== 'admin') die("Access denied.");

$id = $_GET['id'];
$user = $conn->query("SELECT * FROM users WHERE id=$id")->fetch_assoc();

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $role = $_POST['role'];
    $password = $_POST['password'];

    $check = $conn->query("SELECT id FROM users WHERE username='$username' AND id != $id");
    if ($check->num_rows > 0) {
        $error = "Error: Username already exists.";
    } elseif (($username === 'admin' && $role !== 'admin') || ($username === 'user' && $role !== 'user')) {
        $error = "Error: Username and role do not match. 'admin' must have role Admin, 'user' must have role User.";
    } else {
        $updateQuery = "UPDATE users SET username='$username', role='$role'";
        if (!empty($password)) {
            $hashedPassword = md5($password);
            $updateQuery .= ", password='$hashedPassword'";
        }
        $updateQuery .= " WHERE id=$id";
        $conn->query($updateQuery);

        header("Location: view_users.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit User</title>
    
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background: #f0f2f5;
            color: #2c3e50;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            animation: fadeIn 0.5s ease;
        }

        .container {
            background: #fff;
            padding: 50px; /* Increased padding */
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 600px; /* Increased max-width */
            animation: slideUp 0.5s ease-out;
        }

        h2 {
            text-align: center;
            color: #3498db;
            margin-bottom: 30px; /* Increased margin */
            font-size: 36px; /* Increased font size */
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 25px; /* Increased gap between form elements */
        }

        input[type="text"],
        input[type="password"],
        select {
            padding: 16px; /* Increased padding */
            font-size: 18px; /* Increased font size */
            border-radius: 8px;
            border: 1px solid #ccc;
            width: 100%;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }

        input:focus,
        select:focus {
            outline: none;
            border-color: #3498db;
        }

        button {
            padding: 16px; /* Increased padding */
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 18px; /* Increased font size */
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #2980b9;
        }

        .error {
            color: #e74c3c;
            background: #fdecea;
            padding: 12px 18px;
            border-radius: 8px;
            border: 1px solid #f5c6cb;
            margin-bottom: 20px;
            text-align: center;
            font-size: 16px; /* Increased font size */
        }

        .nav-button {
            display: block;
            background-color: #3498db;
            color: white;
            padding: 16px; /* Increased padding */
            text-align: center;
            text-decoration: none;
            border-radius: 8px;
            font-size: 18px; /* Increased font size */
            transition: background-color 0.3s ease;
            margin-top: 25px; /* Increased margin-top */
        }

        .nav-button:hover {
            background-color: #2980b9;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from { transform: translateY(15px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit User</h2>
        <?php if (!empty($error)) echo "<div class='error'>$error</div>"; ?>
        <form method="POST">
            <input name="username" type="text" value="<?= htmlspecialchars($user['username']) ?>" required>
            <select name="role" required>
                <option value="admin" <?= $user['role'] == 'admin' ? 'selected' : '' ?>>Admin</option>
                <option value="user" <?= $user['role'] == 'user' ? 'selected' : '' ?>>User</option>
            </select>
            <input name="password" type="password" placeholder="New Password (leave blank to keep current)">
            <button type="submit">Update</button>
        </form>
        <a href="view_users.php" class="nav-button">← Back to Users</a>
    </div>
</body>
</html>
