<?php
require_once '../config.php';

if (isset($_GET['id'])) {
    $user_id = intval($_GET['id']);

    // Fetch current status
    $result = $conn->query("SELECT status FROM users WHERE id = $user_id");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $new_status = ($row['status'] == 'active') ? 'inactive' : 'active';

        // Update status
        $update = $conn->query("UPDATE users SET status = '$new_status' WHERE id = $user_id");

        if ($update) {
            header("Location: view_users.php?msg=User status updated");
            exit();
        } else {
            echo "Error updating user status.";
        }
    } else {
        echo "User not found.";
    }
} else {
    echo "Invalid request.";
}
?>
