<?php
include "../config.php";
session_start();
if ($_SESSION['role'] !== 'admin') die("Access denied.");

// Handle search and filter inputs
$searchTerm = isset($_GET['search']) ? $_GET['search'] : '';
$filterAction = isset($_GET['action']) ? $_GET['action'] : '';

$sql = "SELECT h.*, a.name AS asset_name, a.description AS asset_description, u.username, u.status 
        FROM history h
        JOIN assets a ON h.asset_id = a.id
        JOIN users u ON h.performed_by = u.id
        WHERE 1";

// Multi-field search
if (!empty($searchTerm)) {
    $searchEscaped = $conn->real_escape_string($searchTerm);
    $sql .= " AND (
        u.username LIKE '%$searchEscaped%' OR
        a.name LIKE '%$searchEscaped%' OR
        a.description LIKE '%$searchEscaped%' OR
        h.action LIKE '%$searchEscaped%' OR
        u.status LIKE '%$searchEscaped%'
    )";
}

// Optional action filter
if (!empty($filterAction)) {
    $filterActionEscaped = $conn->real_escape_string($filterAction);
    $sql .= " AND h.action = '$filterActionEscaped'";
}

$sql .= " ORDER BY h.timestamp DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Activity Logs</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background: #f4f7f9;
            color: #2c3e50;
            animation: fadeIn 0.5s ease-in;
        }

        .container {
            max-width: 1100px;
            margin: auto;
            background: #fff;
            padding: 40px;  /* Increased padding for larger content */
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            animation: slideIn 0.6s ease-out;
        }

        h2 {
            text-align: center;
            margin-bottom: 35px;  /* Increased space between title and content */
            color: #3498db;
            font-size: 36px;  /* Increased font size for the title */
        }

        form {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 15px;  /* Increased gap for better spacing */
            flex-wrap: wrap;
            margin-bottom: 30px;  /* Increased bottom margin for more space */
            transition: all 0.3s ease;
        }

        input[type="text"], select {
            padding: 15px;  /* Increased padding for larger input fields */
            font-size: 18px;  /* Increased font size for the input fields */
            border-radius: 8px;
            border: 1px solid #ccc;
            width: 280px;  /* Increased width for input fields */
            transition: box-shadow 0.3s ease;
        }

        input[type="text"]:focus {
            outline: none;
            border-color: #3498db;
            box-shadow: 0 0 8px rgba(52,152,219,0.4);  /* More pronounced focus shadow */
        }

        button {
            padding: 12px 18px;  /* Larger button padding */
            background-color: #3498db;
            border: none;
            color: white;
            cursor: pointer;
            border-radius: 8px;
            font-size: 18px;  /* Increased font size for buttons */
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        button:hover {
            background-color: #2980b9;
            transform: translateY(-3px);
        }

        a button {
            background-color: #777;
        }

        a button:hover {
            background-color: #555;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;  /* Increased margin for more space between form and table */
            transition: opacity 0.3s ease-in-out;
        }

        th, td {
            padding: 15px 12px;  /* Increased padding for table cells */
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #3498db;
            color: white;
            font-size: 18px;  /* Increased font size for table headers */
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #ecf3fa;
            transition: background-color 0.3s ease;
        }

        .back-btn {
            display: inline-block;
            background-color: #3498db;
            color: white;
            padding: 12px 20px;  /* Larger button padding */
            border-radius: 8px;
            text-decoration: none;
            font-size: 18px;  /* Increased font size */
            transition: background-color 0.3s ease, transform 0.2s ease;
            margin-top: 40px;  /* Increased top margin for better spacing */
            text-align: center;
        }

        .back-btn:hover {
            background-color: #2980b9;
            transform: scale(1.05);
        }

        .no-records {
            text-align: center;
            font-size: 20px;  /* Increased font size for no records message */
            color: #7f8c8d;
            padding: 25px;  /* Increased padding for better visibility */
            transition: color 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideIn {
            from { transform: translateY(15px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>User Activity Logs</h2>

        <form method="GET">
            <input type="text" name="search" placeholder="Search anything..." value="<?= htmlspecialchars($searchTerm) ?>">
            <button type="submit">Search</button>
            <a href="view_history.php"><button type="button">Reset</button></a>
        </form>

        <table>
            <tr>
                <th>Asset</th>
                <th>Description</th>
                <th>Action</th>
                <th>User</th>
                <th>Status</th>
                <th>Time</th>
            </tr>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['asset_name']) ?></td>
                        <td><?= htmlspecialchars($row['asset_description']) ?></td>
                        <td><?= htmlspecialchars($row['action']) ?></td>
                        <td><?= htmlspecialchars($row['username']) ?></td>
                        <td><?= htmlspecialchars($row['status']) ?></td>
                        <td><?= htmlspecialchars($row['timestamp']) ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="6" class="no-records">No records found.</td></tr>
            <?php endif; ?>
        </table>

        <div style="text-align:center;">
            <a href="dashboard.php" class="back-btn">Back to Dashboard</a>
        </div>
    </div>
</body>
</html>
