<?php
include "../config.php";
session_start();
if ($_SESSION['role'] !== 'admin') die("Access denied.");

$searchTerm = isset($_GET['search']) ? $_GET['search'] : '';
$filterAction = isset($_GET['action']) ? $_GET['action'] : '';

$sql = "SELECT h.id, h.item_id AS asset_id, h.performed_by, h.action, h.timestamp, h.quantity,
        a.name AS asset_name, a.description AS asset_description,
        u.username, u.status 
        FROM history h
        LEFT JOIN items a ON h.item_id = a.id
        JOIN users u ON h.performed_by = u.id
        WHERE 1";

if (!empty($searchTerm)) {
    $searchEscaped = $conn->real_escape_string($searchTerm);
    $sql .= " AND (
        u.username LIKE '%$searchEscaped%' OR
        a.name LIKE '%$searchEscaped%' OR
        a.description LIKE '%$searchEscaped%' OR
        h.action LIKE '%$searchEscaped%' OR
        u.status LIKE '%$searchEscaped%'
    )";
}

if (!empty($filterAction)) {
    $filterActionEscaped = $conn->real_escape_string($filterAction);
    $sql .= " AND h.action = '$filterActionEscaped'";
}

$sql .= " ORDER BY h.timestamp DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Activity Logs</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #1a1a1a, #2c2c2c, #3d3d3d);
            color: #eee;
            padding: 40px 20px;
            animation: fadeIn 0.5s ease-in;
        }

        .container {
            max-width: 1100px;
            margin: auto;
            background: rgba(70, 70, 70, 0.85);
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(255, 102, 0, 0.35);
            animation: slideIn 0.6s ease-out;
            backdrop-filter: saturate(180%) blur(12px);
        }

        h2 {
            text-align: center;
            margin-bottom: 35px;
            color: #ff6600;
            font-size: 36px;
            text-shadow: 0 0 8px #ff6600;
        }

        form {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 30px;
        }

        input[type="text"] {
            padding: 14px;
            font-size: 18px;
            border-radius: 12px;
            border: 2px solid #555;
            width: 280px;
            background: #222;
            color: #eee;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        input::placeholder {
            color: #999;
            font-style: italic;
        }

        input:focus {
            border-color: #ff6600;
            outline: none;
            box-shadow: 0 0 10px #ff6600;
            background: #333;
        }

        button {
            padding: 14px 22px;
            background: transparent;
            border: 2px solid #eee;
            color: #eee;
            font-size: 18px;
            font-weight: 600;
            border-radius: 12px;
            cursor: pointer;
            transition:
                background-color 0.3s ease,
                color 0.3s ease,
                box-shadow 0.3s ease,
                transform 0.3s ease;
        }

        button:hover {
            background-color: #ff6600;
            color: #fff;
            transform: translateY(-2px);
            box-shadow: 0 0 10px #ff6600, 0 0 20px #ff6600;
        }

        a button {
            background-color: transparent;
            border: 2px solid #aaa;
        }

        a button:hover {
            background-color: #ff6600;
            color: #fff;
            border-color: #ff6600;
            box-shadow: 0 0 10px #ff6600;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: #333;
            border-radius: 12px;
            overflow: hidden;
        }

        th, td {
            padding: 15px 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            text-align: left;
            font-size: 16px;
        }

        th {
            background-color: #444;
            color: #fff;
            font-size: 18px;
            font-weight: 700;
            text-transform: uppercase;
        }

        tr:nth-child(even) {
            background-color: #2e2e2e;
        }

        tr:hover {
            background-color: rgba(255, 255, 255, 0.1);
            transition: background-color 0.3s ease;
        }

        .no-records {
            text-align: center;
            font-size: 20px;
            color: #ccc;
            padding: 25px;
        }

        .back-btn {
            display: inline-block;
            background: transparent;
            border: 2px solid #eee;
            color: #eee;
            padding: 14px 28px;
            font-size: 18px;
            border-radius: 12px;
            margin-top: 40px;
            font-weight: 600;
            text-decoration: none;
            transition:
                background-color 0.3s ease,
                color 0.3s ease,
                box-shadow 0.3s ease,
                transform 0.3s ease;
        }

        .back-btn:hover {
            background-color: #ff6600;
            color: #fff;
            transform: translateY(-3px);
            box-shadow: 0 0 10px #ff6600, 0 0 20px #ff6600;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideIn {
            from { transform: translateY(15px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>User Activity Logs</h2>

        <form method="GET">
            <input type="text" name="search" placeholder="Search anything..." value="<?= htmlspecialchars($searchTerm) ?>">
            <button type="submit">Search</button>
            <a href="view_history.php"><button type="button">Reset</button></a>
        </form>

        <table>
            <tr>
                <th>Asset</th>
                <th>Description</th>
                <th>Action</th>
                <th>User</th>
                <th>Status</th>
                <th>Time</th>
            </tr>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['asset_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($row['asset_description'] ?? '-') ?></td>
                        <td>
                            <?php 
                                $action = htmlspecialchars($row['action']);
                                if (empty($row['asset_name'])) {
                                    // Asset deleted, show 'Item Removed'
                                    echo "Item Removed";
                                    if (in_array($action, ['Item Added', 'Item Removed'])) {
                                        $qty = intval($row['quantity'] ?? 0);
                                        echo " (Quantity: $qty)";
                                    }
                                } else {
                                    if (in_array($action, ['Item Added', 'Item Removed'])) {
                                        $qty = intval($row['quantity'] ?? 0);
                                        echo $action . " (Quantity: $qty)";
                                    } else {
                                        echo $action;
                                    }
                                }
                            ?>
                        </td>
                        <td><?= htmlspecialchars($row['username']) ?></td>
                        <td><?= htmlspecialchars($row['status']) ?></td>
                        <td><?= htmlspecialchars($row['timestamp']) ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="6" class="no-records">No records found.</td></tr>
            <?php endif; ?>
        </table>

        <div style="text-align:center;">
            <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
        </div>
    </div>
</body>
</html>
