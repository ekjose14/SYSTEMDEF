<?php
include "../config.php";
session_start();
if ($_SESSION['role'] !== 'admin') die("Access denied.");

$result = $conn->query("SELECT * FROM users");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Accounts</title>
    <style>
        /* Base Reset */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body, html {
            height: 100%;
            background: linear-gradient(135deg, #1a1a1a, #2c2c2c, #3d3d3d);
            color: #eee;
            overflow-x: hidden;
            padding: 40px 20px;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            background-color: rgba(70, 70, 70, 0.85);
            padding: 36px 40px;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(255, 102, 0, 0.35);
            animation: slideIn 0.7s ease-out;
            backdrop-filter: saturate(180%) blur(12px);
        }

        h2 {
            color: #ff6600;
            text-align: center;
            margin-bottom: 40px;
            font-size: 36px;
            text-shadow: 0 0 8px #ff6600;
        }

        .top-buttons {
            display: flex;
            justify-content: flex-end;
            gap: 15px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }

        .nav-button {
            background: transparent;
            border: 2px solid #eee;
            border-radius: 12px;
            color: #eee;
            padding: 14px 28px;
            font-size: 18px;
            cursor: pointer;
            text-decoration: none;
            text-align: center;
            transition:
                background-color 0.3s ease,
                color 0.3s ease,
                box-shadow 0.3s ease,
                transform 0.2s ease;
            user-select: none;
            font-weight: 600;
            letter-spacing: 0.05em;
        }

        .nav-button:hover {
            background-color: #ff6600;
            color: #fff;
            font-weight: 700;
            box-shadow: 0 0 10px #ff6600, 0 0 20px #ff6600;
            transform: translateY(-3px);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.3);
            background-color: #333;
            border-radius: 12px;
            overflow: hidden;
        }

        th, td {
            padding: 15px 12px;
            border-bottom: 1px solid rgba(255,255,255,0.2);
            text-align: left;
            font-size: 16px;
            color: white;
            text-shadow: 0 0 2px rgba(0,0,0,0.6);
        }

        th {
            background-color: #444;
            font-size: 18px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.03em;
        }

        tr:nth-child(even) {
            background-color: #2e2e2e;
        }

        tr:hover {
            background-color: rgba(255, 255, 255, 0.15);
            transition: background-color 0.3s ease;
            cursor: default;
        }

        td a {
            background: transparent;
            border: 2px solid #eee;
            color: #eee;
            padding: 8px 14px;
            border-radius: 10px;
            text-decoration: none;
            font-size: 16px;
            margin-right: 10px;
            display: inline-block;
            transition:
                background-color 0.3s ease,
                color 0.3s ease,
                box-shadow 0.3s ease,
                transform 0.2s ease;
            font-weight: 500;
        }

        td a:hover {
            background-color: #ff6600 !important;
            color: #fff !important;
            font-weight: 700;
            transform: translateY(-2px);
            box-shadow: 0 0 10px #ff6600, 0 0 16px #ff6600;
        }

        tr:hover td a:hover {
            background-color: #ff6600 !important;
        }

        @keyframes slideIn {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>User Accounts</h2>

        <div class="top-buttons">
            <a href="add_user.php" class="nav-button">Add New User</a>
            <a href="dashboard.php" class="nav-button">Back to Dashboard</a>
        </div>

        <table>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Role</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['id']) ?></td>
                <td><?= htmlspecialchars($row['username']) ?></td>
                <td><?= htmlspecialchars($row['role']) ?></td>
                <td><?= ucfirst(htmlspecialchars($row['status'])) ?></td>
                <td>
                    <a href="edit_user.php?id=<?= urlencode($row['id']) ?>">Edit</a>
                    <a href="toggle_user_status.php?id=<?= urlencode($row['id']) ?>"
                       onclick="return confirm('Are you sure you want to <?= ($row['status'] == 'active') ? 'deactivate' : 'activate' ?> this user?')">
                       <?= ($row['status'] == 'active') ? 'Deactivate' : 'Activate' ?>
                    </a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>
