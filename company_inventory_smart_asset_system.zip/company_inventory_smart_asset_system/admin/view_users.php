<?php
include "../config.php";
session_start();
if ($_SESSION['role'] !== 'admin') die("Access denied.");

$result = $conn->query("SELECT * FROM users");
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Accounts</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7fa;
            margin: 0;
            padding: 30px;
            animation: fadeIn 0.5s ease;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            background-color: #fff;
            padding: 40px; /* Increased padding for a larger layout */
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            animation: slideIn 0.6s ease-out;
        }

        h2 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 35px; /* Increased margin for more spacing */
            font-size: 36px; /* Increased font size */
        }

        .top-buttons {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 15px; /* Increased gap between buttons */
            margin-bottom: 25px; /* Increased margin for more space */
        }

        .nav-button {
            background-color: #3498db;
            color: white;
            padding: 12px 20px; /* Increased padding */
            border: none;
            border-radius: 8px; /* Slightly more rounded edges */
            text-decoration: none;
            font-size: 18px; /* Increased font size */
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .nav-button:hover {
            background-color: #2980b9;
            transform: translateY(-3px); /* Slightly more pronounced hover effect */
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px; /* Increased margin for more spacing */
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.03);
        }

        th, td {
            padding: 15px 12px; /* Increased padding for table cells */
            border: 1px solid #e0e0e0;
            text-align: left;
            font-size: 16px; /* Increased font size for better readability */
        }

        th {
            background-color: #ecf0f1;
            color: #2c3e50;
            font-size: 18px; /* Increased font size for table headers */
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #eef6fb;
            transition: background-color 0.3s ease;
        }

        td a {
            background-color: #3498db;
            color: white;
            padding: 8px 14px; /* Increased padding for action buttons */
            border-radius: 8px;
            text-decoration: none;
            font-size: 16px; /* Increased font size for action links */
            margin-right: 12px; /* Increased margin between action buttons */
            display: inline-block;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        td a:hover {
            background-color: #2980b9;
            transform: scale(1.05);
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideIn {
            from { transform: translateY(15px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>User Accounts</h2>

        <div class="top-buttons">
            <a href="add_user.php" class="nav-button">Add New User</a>
            <a href="dashboard.php" class="nav-button">Back to Dashboard</a>
        </div>

        <table>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Role</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= $row['username'] ?></td>
                <td><?= $row['role'] ?></td>
                <td><?= ucfirst($row['status']) ?></td>
                <td>
                    <a href="edit_user.php?id=<?= $row['id'] ?>">Edit</a>
                    <a href="toggle_user_status.php?id=<?= $row['id'] ?>"
                       onclick="return confirm('Are you sure you want to <?= ($row['status'] == 'active') ? 'deactivate' : 'activate' ?> this user?')">
                       <?= ($row['status'] == 'active') ? 'Deactivate' : 'Activate' ?>
                    </a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>
