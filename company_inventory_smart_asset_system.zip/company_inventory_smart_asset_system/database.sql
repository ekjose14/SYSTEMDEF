-- SQL file to create tables
CREATE TABLE users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50), password VARCHAR(255), role ENUM('admin','user'));
CREATE TABLE assets (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), description TEXT, added_by INT, date_added TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE history (id INT AUTO_INCREMENT PRIMARY KEY, asset_id INT, action VARCHAR(100), performed_by INT, timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP);