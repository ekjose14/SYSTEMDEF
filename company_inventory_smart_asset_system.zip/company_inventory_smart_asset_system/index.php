<?php
session_start();
include "config.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = md5($_POST['password']);

    $stmt = $conn->prepare("SELECT id, username, password, role, status FROM users WHERE username = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if ($user['status'] !== 'active') {
            $error = "Your account has been deactivated. Please contact the administrator.";
        } else {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            header("Location: " . $user['role'] . "/dashboard.php");
            exit;
        }
    } else {
        $error = "Invalid username or password.";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Tally Ho! – Where Everything Counts.</title>
  <style>
    /* Reset & base */
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    body, html {
      height: 100%;
      background: linear-gradient(135deg, #1a1a1a, #2c2c2c, #3d3d3d);
      color: #e0e0e0;
      overflow: hidden;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
    }

    .container {
      display: flex;
      height: 100vh;
    }

    /* Sidebar */
    .sidebar {
      background: linear-gradient(180deg, rgba(60, 60, 60, 0.9), rgba(90, 90, 90, 0.7));
      width: 220px;
      padding-top: 40px;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 20px;
      box-shadow: 5px 0 15px rgba(20, 20, 20, 0.7);
      backdrop-filter: saturate(180%) blur(12px);
      border-right: 1px solid #555;
    }

    .sidebar button {
      background: transparent;
      border: 2px solid #ddd;
      border-radius: 12px;
      color: #ddd;
      padding: 14px 24px;
      font-size: 18px;
      width: 160px;
      cursor: pointer;
      text-align: center;
      transition: 
        background-color 0.4s ease, 
        color 0.4s ease, 
        box-shadow 0.3s ease,
        transform 0.3s ease;
      user-select: none;
      font-weight: 600;
      letter-spacing: 0.05em;
    }

    .sidebar button:hover,
    .sidebar button.active {
      background: #ff6600; /* Orange */
      color: #fff;
      font-weight: 700;
      box-shadow: 0 0 10px #ff6600, 0 0 20px #ff6600;
      transform: translateX(6px);
    }

    /* Content */
    .content {
      flex-grow: 1;
      padding: 60px 60px;
      overflow-y: auto;
      background: linear-gradient(135deg, rgba(50,50,50,0.85), rgba(80,80,80,0.95));
      border-radius: 0 30px 30px 0;
      box-shadow: inset 0 0 80px rgba(255, 255, 255, 0.03);
      color: #ddd;
      backdrop-filter: saturate(180%) blur(8px);
    }

    /* Homepage welcome text */
    #homeText {
      max-width: 700px;
      margin: auto;
      text-align: center;
    }

    #homeText h1 {
      font-size: 52px;
      margin-bottom: 16px;
      color: #eaeaea;
      text-shadow: 0 0 10px #ff6600, 0 0 14px #ff6600; /* orange glow */
      font-weight: 900;
      letter-spacing: 0.1em;
    }

    #homeText p {
      font-size: 26px;
      line-height: 1.5;
      margin-bottom: 48px;
      color: #ccc;
      text-shadow: 0 0 4px rgba(0,0,0,0.7);
    }

   /* Login Form */
#loginForm {
  max-width: 400px;
  margin: auto;
  background: rgba(70, 70, 70, 0.85);
  color: #eee;
  padding: 42px 36px;
  border-radius: 16px;
  box-shadow: 0 10px 25px rgba(255, 102, 0, 0.35);
  display: none;
  animation: slideIn 0.7s ease-in-out;
  backdrop-filter: saturate(180%) blur(12px);
}

#loginForm h2 {
  color: #ff6600;
  margin-bottom: 24px;
  font-size: 36px;
  font-weight: 800;
  text-align: center;
  letter-spacing: 0.08em;
  text-shadow: 0 0 8px #ff6600;
}

#loginForm input[type="text"],
#loginForm input[type="password"] {
  padding: 16px 18px;
  font-size: 18px;
  border: 2px solid #555;
  border-radius: 12px;
  margin-bottom: 28px;
  width: 100%;
  background: #222;
  color: #eee;
  transition:
    border-color 0.4s ease,
    box-shadow 0.4s ease,
    background-color 0.4s ease;
}

#loginForm input[type="text"]::placeholder,
#loginForm input[type="password"]::placeholder {
  color: #999;
  font-style: italic;
}

#loginForm input[type="text"]:focus,
#loginForm input[type="password"]:focus {
  border-color: #ff6600;
  outline: none;
  box-shadow: 0 0 10px #ff6600;
  background: #333;
}

#loginForm button {
  padding: 16px;
  font-size: 20px;
  background-color: transparent;
  border: 2px solid #eee;
  border-radius: 12px;
  color: #eee;
  width: 100%;
  font-weight: 600;
  letter-spacing: 0.05em;
  transition:
    background-color 0.4s ease,
    color 0.4s ease,
    box-shadow 0.3s ease,
    transform 0.3s ease;
  cursor: pointer;
}

#loginForm button:hover {
  background-color: #ff6600;
  color: #fff;
  font-weight: 700;
  box-shadow: 0 0 10px #ff6600, 0 0 20px #ff6600;
  transform: translateY(-3px);
}

/* Login error message */
#loginError {
  color: #ff4c4c;
  margin-bottom: 20px;
  font-weight: 700;
  text-align: center;
  text-shadow: 0 0 6px #ff4c4c;
}

/* About & Contact placeholder */
#infoText {
  max-width: 700px;
  margin: auto;
  font-size: 24px;
  text-align: center;
  margin-top: 80px;
  line-height: 1.6;
  color: #ccc;
  display: none;
  text-shadow: 0 0 4px rgba(0,0,0,0.6);
}

/* Animations */
@keyframes slideIn {
  from { transform: translateY(-20px); opacity: 0; }
  to { transform: translateY(0); opacity: 1; }
}

/* Scrollbar styling for WebKit */
.content::-webkit-scrollbar {
  width: 10px;
}
.content::-webkit-scrollbar-track {
  background: #222;
  border-radius: 10px;
}
.content::-webkit-scrollbar-thumb {
  background: #ff6600;
  border-radius: 10px;
  border: 2px solid #222;
}
  </style>
</head>
<body>
   <div class="container">
    <nav class="sidebar">
      <button id="btnHome" class="active">Home</button>
      <button id="btnLogin">Login</button>
      <button id="btnAbout">About</button>
      <button id="btnContact">Contact Us</button>
    </nav>

    <main class="content">
      <section id="homeText">
        <h1>Tally Ho!</h1>
        <p>Tally Ho! – Where Everything Counts.<br><br>
        Welcome to your all-in-one asset and inventory management system designed to keep track of every item with ease and accuracy.</p>
      </section>

      <section id="loginForm">
        <?php if (!empty($error)) echo '<p class="error-msg" style="color:#ff5555; font-weight:600; text-align:center;">' . htmlspecialchars($error) . '</p>'; ?>
        <h2>Login</h2>
        <form method="POST" action="">
          <input name="username" type="text" placeholder="Username" required autocomplete="username" />
          <input name="password" type="password" placeholder="Password" required autocomplete="current-password" />
          <button type="submit">Login</button>
        </form>
      </section>

      <section id="infoText"></section>
    </main>
  </div>

  <script>
    const btnHome = document.getElementById('btnHome');
    const btnLogin = document.getElementById('btnLogin');
    const btnAbout = document.getElementById('btnAbout');
    const btnContact = document.getElementById('btnContact');

    const homeText = document.getElementById('homeText');
    const loginForm = document.getElementById('loginForm');
    const infoText = document.getElementById('infoText');

    function clearActive() {
      [btnHome, btnLogin, btnAbout, btnContact].forEach(btn => btn.classList.remove('active'));
    }

    btnHome.addEventListener('click', () => {
      clearActive();
      btnHome.classList.add('active');
      homeText.style.display = 'block';
      loginForm.style.display = 'none';
      infoText.style.display = 'none';
    });

    btnLogin.addEventListener('click', () => {
      clearActive();
      btnLogin.classList.add('active');
      homeText.style.display = 'none';
      infoText.style.display = 'none';
      loginForm.style.display = 'block';
    });

    btnAbout.addEventListener('click', () => {
      clearActive();
      btnAbout.classList.add('active');
      homeText.style.display = 'none';
      loginForm.style.display = 'none';
      infoText.style.display = 'block';
      infoText.innerHTML = "<h2>About Tally Ho!</h2><p>Tally Ho! is your trusted system for asset and inventory management, making counting, tracking, and reporting simple and efficient.</p>";
    });

    btnContact.addEventListener('click', () => {
      clearActive();
      btnContact.classList.add('active');
      homeText.style.display = 'none';
      loginForm.style.display = 'none';
      infoText.style.display = 'block';
      infoText.innerHTML = "<h2>Contact Us</h2><p>Need help? Reach out to our support team at support@tallyho.com or call (123) 456-7890.</p>";
    });

    window.addEventListener('DOMContentLoaded', () => {
      <?php if (!empty($error)) : ?>
        btnLogin.click(); // show login tab if error
      <?php else : ?>
        btnHome.click(); // default view
      <?php endif; ?>
    });

  </script>
</body>
</html>
