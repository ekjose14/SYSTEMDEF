<?php
session_start();
include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = md5($_POST['password']);

    $stmt = $conn->prepare("SELECT id, username, password, role, status FROM users WHERE username = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if ($user['status'] !== 'active') {
            $error = "Your account has been deactivated. Please contact the administrator.";
        } else {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];

            header("Location: " . $user['role'] . "/dashboard.php");
            exit;
        }
    } else {
        $error = "Invalid username or password.";
    }

    $stmt->close();
}
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="css/style.css"></head>
<body>
<style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f0f4f8;
    color: #333;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    animation: fadeIn 0.8s ease-in-out;
}

form {
    background-color: #ffffff;
    padding: 36px; /* Increased padding */
    border-radius: 12px;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1); /* Slightly bigger shadow */
    display: flex;
    flex-direction: column;
    gap: 24px; /* Increased gap between form elements */
    min-width: 350px; /* Slightly larger form width */
    animation: slideIn 0.7s ease-in-out;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

form:hover {
    transform: scale(1.02);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
}

input[type="text"],
input[type="password"] {
    padding: 16px; /* Increased padding */
    font-size: 18px; /* Increased font size */
    border: 1px solid #d1dce5;
    border-radius: 8px; /* More rounded corners */
    background-color: #ffffff;
    color: #333;
    transition: border-color 0.3s, box-shadow 0.3s;
}

input[type="text"]:focus,
input[type="password"]:focus {
    border-color: #3f8ec1;
    outline: none;
    box-shadow: 0 0 5px rgba(63, 142, 193, 0.4);
}

button {
    padding: 16px; /* Increased padding */
    font-size: 18px; /* Increased font size */
    background-color: #3f8ec1;
    color: #ffffff;
    border: none;
    border-radius: 8px; /* More rounded corners */
    cursor: pointer;
    transition: background-color 0.3s, transform 0.2s;
}

button:hover {
    background-color: #3576a6;
    transform: translateY(-2px);
}

h2 {
    color: #3f8ec1;
    margin-bottom: 12px; /* Increased margin */
    font-size: 32px; /* Larger font size for the header */
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

@keyframes slideIn {
    from { transform: translateY(-20px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}
</style>

    <form method="POST">
        <h2>Login</h2>
        <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
        <input name="username" type="text" placeholder="Username" required>
        <input name="password" type="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>
</body>
</html>
