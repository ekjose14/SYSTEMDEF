<?php
session_start();
include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = md5($_POST['password']);

    $stmt = $conn->prepare("SELECT id, username, password, role, status FROM users WHERE username = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if ($user['status'] !== 'active') {
            $error = "Your account has been deactivated. Please contact the administrator.";
        } else {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];

            header("Location: " . $user['role'] . "/dashboard.php");
            exit;
        }
    } else {
        $error = "Invalid username or password.";
    }

    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Login - Tally Ho!</title>
 
</head>
<body>
  <div class="container">
    <nav class="sidebar">
      <button onclick="window.location.href='index.php'">Home</button>
      <button class="active">Login</button>
      <button onclick="alert('About page coming soon!')">About</button>
      <button onclick="alert('Contact page coming soon!')">Contact Us</button>
    </nav>

    <main class="content">
      <form method="POST" action="">
        <h2>Login</h2>
        <?php if (isset($error)) echo '<p class="error-msg">' . htmlspecialchars($error) . '</p>'; ?>
        <input name="username" type="text" placeholder="Username" required autocomplete="username" />
        <input name="password" type="password" placeholder="Password" required autocomplete="current-password" />
        <button type="submit">Login</button>
      </form>
    </main>
  </div>
</body>
</html>
