<?php 
include "../config.php";
session_start();
if ($_SESSION['role'] !== 'user') die("Access denied.");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $quantity = (int)$_POST['quantity'];
    $user_id = $_SESSION['user_id'];

    // Handle image upload
    $image_path = '';
    if (isset($_FILES['asset_image']) && $_FILES['asset_image']['error'] === 0) {
        $target_dir = "../uploads/";
        if (!is_dir($target_dir)) mkdir($target_dir);
        $filename = uniqid() . "_" . basename($_FILES["asset_image"]["name"]);
        $target_file = $target_dir . $filename;

        if (move_uploaded_file($_FILES["asset_image"]["tmp_name"], $target_file)) {
            $image_path = "uploads/" . $filename;
        }
    }

     $conn->query("INSERT INTO items (name, description, quantity, image_path, added_by) 
                  VALUES ('$name', '$description', $quantity, '$image_path', $user_id)");
    $asset_id = $conn->insert_id;

	
       // <-- Insert fetch admin id snippet here -->
    $admin_query = $conn->query("SELECT id FROM users WHERE role = 'admin' LIMIT 1");
    $admin = $admin_query->fetch_assoc();
    $admin_id = $admin ? $admin['id'] : $user_id;

    // Fixed: Include quantity in history
    $conn->query("INSERT INTO history (item_id, action, performed_by, quantity) 
                  VALUES ($asset_id, 'Item Added', $admin_id, $quantity)");


    header("Location: view_assets.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Add Asset</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0; padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #1a1a1a, #2c2c2c, #3d3d3d);
            color: #eee;
            padding: 40px 20px;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            animation: fadeIn 0.8s ease-in;
        }

        .container {
            background: rgba(70, 70, 70, 0.85);
            max-width: 600px;
            width: 100%;
            padding: 50px 40px;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(255, 102, 0, 0.35);
            backdrop-filter: saturate(180%) blur(12px);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .container:hover {
            transform: translateY(-5px);
            box-shadow: 0 14px 35px rgba(255, 102, 0, 0.5);
        }

        h2 {
            text-align: center;
            font-size: 32px;
            margin-bottom: 30px;
            color: #ff6600;
            font-weight: 800;
            text-shadow: 0 0 8px #ff6600;
            transition: color 0.3s ease;
        }
        h2:hover {
            color: #ff994d;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 24px;
        }

        input[type="text"],
        input[type="number"],
        textarea,
        input[type="file"] {
            padding: 16px;
            font-size: 18px;
            border-radius: 12px;
            border: 2px solid #555;
            background: #222;
            color: #eee;
            transition: border-color 0.3s ease, box-shadow 0.3s ease, background-color 0.3s ease;
            width: 100%;
            resize: vertical;
        }

        input::placeholder,
        textarea::placeholder {
            color: #999;
            font-style: italic;
        }

        input[type="text"]:focus,
        input[type="number"]:focus,
        textarea:focus {
            border-color: #ff6600;
            outline: none;
            box-shadow: 0 0 10px #ff6600;
            background-color: #333;
        }

        input[type="file"] {
            cursor: pointer;
            color: #eee;
        }
        input[type="file"]:hover {
            opacity: 0.85;
        }

        button {
            padding: 16px;
            font-size: 18px;
            font-weight: 600;
            border-radius: 12px;
            border: 2px solid #eee;
            background: transparent;
            color: #eee;
            cursor: pointer;
            transition:
                background-color 0.3s ease,
                color 0.3s ease,
                box-shadow 0.3s ease,
                transform 0.3s ease;
        }
        button:hover {
            background-color: #ff6600;
            color: #fff;
            box-shadow: 0 0 12px #ff6600, 0 0 24px #ff6600;
            transform: translateY(-3px);
        }

        .nav-button {
            display: block;
            background: transparent;
            border: 2px solid #eee;
            color: #eee;
            text-align: center;
            text-decoration: none;
            padding: 16px;
            font-size: 18px;
            border-radius: 12px;
            margin-top: 30px;
            font-weight: 600;
            transition:
                background-color 0.3s ease,
                color 0.3s ease,
                box-shadow 0.3s ease,
                transform 0.3s ease;
        }
        .nav-button:hover {
            background-color: #ff6600;
            color: #fff;
            box-shadow: 0 0 12px #ff6600, 0 0 24px #ff6600;
            transform: translateY(-3px);
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Add Item</h2>
        <form method="POST" enctype="multipart/form-data">
            <input name="name" type="text" placeholder="Item Name" required>
            <textarea name="description" placeholder="Item Description" required rows="4"></textarea>
            <input type="number" name="quantity" placeholder="Quantity" required min="1">
            <input type="file" name="asset_image" accept="image/*" capture="environment">
            <button type="submit">Add</button>
        </form>
        <a href="dashboard.php" class="nav-button">Back</a>
    </div>
</body>
</html>
