<?php 
include "../config.php";
session_start();
if ($_SESSION['role'] !== 'user') die("Access denied.");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $quantity = (int)$_POST['quantity'];
    $user_id = $_SESSION['user_id'];

    // Handle image upload
    $image_path = '';
    if (isset($_FILES['asset_image']) && $_FILES['asset_image']['error'] === 0) {
        $target_dir = "../uploads/";
        if (!is_dir($target_dir)) mkdir($target_dir); // Ensure directory exists
        $filename = uniqid() . "_" . basename($_FILES["asset_image"]["name"]);
        $target_file = $target_dir . $filename;

        if (move_uploaded_file($_FILES["asset_image"]["tmp_name"], $target_file)) {
            $image_path = "uploads/" . $filename;
        }
    }

    $conn->query("INSERT INTO assets (name, description, quantity, image_path, added_by) 
                  VALUES ('$name', '$description', $quantity, '$image_path', $user_id)");
    $asset_id = $conn->insert_id;

    $conn->query("INSERT INTO history (asset_id, action, performed_by) 
                  VALUES ($asset_id, 'Added Asset', $user_id)");

    header("Location: view_assets.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Asset</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f7f9;
            color: #2c3e50;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background: #fff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
        }
        .container:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.15);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #3498db;
            font-size: 28px;
            transition: color 0.3s ease;
        }
        h2:hover {
            color: #2980b9;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        input[type="text"], input[type="number"], textarea, input[type="file"] {
            padding: 14px;
            font-size: 16px;
            border-radius: 8px;
            border: 1px solid #ccc;
            width: 100%;
            box-sizing: border-box;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        input[type="text"]:focus,
        input[type="number"]:focus,
        textarea:focus {
            border-color: #3498db;
            outline: none;
            box-shadow: 0 0 5px rgba(52, 152, 219, 0.4);
        }
        input[type="file"]:hover {
            cursor: pointer;
            opacity: 0.8;
        }
        button {
            padding: 14px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        button:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
        }
        .nav-button {
            display: block;
            background-color: #3498db;
            color: white;
            padding: 14px;
            text-align: center;
            text-decoration: none;
            border-radius: 8px;
            font-size: 16px;
            transition: background-color 0.3s ease, transform 0.3s ease;
            margin-top: 20px;
        }
        .nav-button:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Add Item</h2>
        <form method="POST" enctype="multipart/form-data">
            <input name="name" placeholder="Item Name" required>
            <textarea name="description" placeholder="Item Description" required></textarea>
            <input type="number" name="quantity" placeholder="Quantity" required min="1">
            <input type="file" name="asset_image" accept="image/*" capture="environment">
            <button type="submit">Add</button>
        </form>
        <a href="dashboard.php" class="nav-button">Back</a>
    </div>
</body>
</html>
