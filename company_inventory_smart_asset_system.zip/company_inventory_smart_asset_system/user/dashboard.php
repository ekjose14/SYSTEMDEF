<?php
session_start();
if ($_SESSION['role'] !== 'user') die("Access denied.");
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #e9eef3;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
            animation: fadeIn 0.8s ease-in;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background: #fff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            animation: popIn 0.6s ease-in-out;
        }

        h2 {
            font-size: 32px;  /* Increased font size */
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 40px;
            animation: slideDown 0.6s ease-in-out;
            text-align: center; /* Centered title inside the container */
        }

        nav {
            display: flex;
            flex-direction: column;
            gap: 20px;
            animation: popIn 0.6s ease-in-out;
            text-align: center;
        }

        .nav-button {
            background-color: #3498db;
            color: white;
            padding: 20px 40px;  /* Increased padding to make buttons bigger */
            font-size: 22px;  /* Increased font size */
            border: none;
            border-radius: 6px;
            text-decoration: none;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .nav-button:hover {
            background-color: #2980b9;
            transform: translateY(-3px) scale(1.03);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }

        .nav-button:focus {
            outline: 3px solid #85c1e9;
        }

        @media (min-width: 480px) {
            nav {
                flex-direction: row;
                justify-content: center;
                flex-wrap: wrap;
            }
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideDown {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        @keyframes popIn {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>User Dashboard</h2>
        <nav>
            <a href="add_asset.php" class="nav-button">Add Item</a>
            <a href="view_assets.php" class="nav-button">View Items</a>
            <a href="../logout.php" class="nav-button">Logout</a>
        </nav>
    </div>
</body>
</html>
