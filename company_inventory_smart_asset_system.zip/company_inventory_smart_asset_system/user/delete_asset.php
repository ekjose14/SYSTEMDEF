<?php
include "../config.php";
session_start();
if ($_SESSION['role'] !== 'user') die("Access denied.");

$user_id = $_SESSION['user_id'];
$result = $conn->query("SELECT * FROM assets WHERE added_by=$user_id");
?>
<!DOCTYPE html>
<html>
<head>

</head>
<body>
    <h2>Inventory</h2>
    <table border="1" cellpadding="5">
        <tr><th>ID</th><th>Name</th><th>Description</th><th>Date Added</th><th>Action</th></tr>
        <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['name'] ?></td>
            <td><?= $row['description'] ?></td>
            <td><?= $row['date_added'] ?></td>
            <td>
                <a href="delete_asset.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete this asset?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    <br><a href="dashboard.php">Back</a>
</body>
</html>