<?php
// delete_asset.php
include "../config.php";
session_start();

// Only logged-in “user” can delete
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    die("Access denied.");
}

if (!isset($_GET['id'])) {
    // No asset ID passed → back to list
    header("Location: view_assets.php");
    exit;
}

$asset_id = (int)$_GET['id'];
$user_id  = (int)$_SESSION['user_id'];

// 1) Fetch record (and image path) to confirm ownership & later unlink
$stmt = $conn->prepare("SELECT image_path FROM assets WHERE id = ? AND added_by = ?");
$stmt->bind_param("ii", $asset_id, $user_id);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 1) {
    $row = $res->fetch_assoc();

    // 2) Remove image file if exists
    if (!empty($row['image_path']) && file_exists(__DIR__ . "/../" . $row['image_path'])) {
        @unlink(__DIR__ . "/../" . $row['image_path']);
    }

    // 3) Delete the asset
    $del = $conn->prepare("DELETE FROM assets WHERE id = ? AND added_by = ?");
    $del->bind_param("ii", $asset_id, $user_id);
    $del->execute();
    $del->close();

    // 4) (Optional) Log to history
    $log = $conn->prepare(
        "INSERT INTO history (asset_id, action, performed_by)
         VALUES (?, 'Deleted Asset', ?)"
    );
    $log->bind_param("ii", $asset_id, $user_id);
    $log->execute();
    $log->close();
}

$stmt->close();

// 5) Redirect straight back to your list
header("Location: view_assets.php");
exit;
?>
