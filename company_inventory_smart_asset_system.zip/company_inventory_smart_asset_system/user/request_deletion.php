<?php
include "../config.php";
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    die("Access denied.");
}

$user_id = (int)$_SESSION['user_id'];

if (!isset($_GET['id'])) {
    header("Location: view_assets.php");
    exit;
}

$asset_id = (int)$_GET['id'];
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $quantity = (int)$_POST['quantity'];
    $reason = trim($_POST['reason']);

    if ($quantity <= 0) {
        $error = "Quantity must be greater than zero.";
    } else {
        // Optional: Check if user owns the asset and has enough quantity
        $stmt = $conn->prepare("SELECT quantity FROM assets WHERE id = ? AND added_by = ?");
        $stmt->bind_param("ii", $asset_id, $user_id);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res->num_rows !== 1) {
            $error = "Asset not found or unauthorized.";
        } else {
            $row = $res->fetch_assoc();
            if ($quantity > $row['quantity']) {
                $error = "Requested quantity exceeds your asset quantity.";
            } else {
                // Insert deletion request
                $stmt2 = $conn->prepare("INSERT INTO delete_requests (user_id, asset_id, quantity, reason, timestamp) VALUES (?, ?, ?, ?, NOW())");
                $stmt2->bind_param("iiis", $user_id, $asset_id, $quantity, $reason);
                $stmt2->execute();
                $stmt2->close();

                header("Location: view_assets.php?msg=Request submitted successfully.");
                exit;
            }
        }
        $stmt->close();
    }
}

// Fetch asset info for display
$stmt = $conn->prepare("SELECT name, quantity FROM assets WHERE id = ? AND added_by = ?");
$stmt->bind_param("ii", $asset_id, $user_id);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows !== 1) {
    die("Asset not found or unauthorized.");
}
$asset = $res->fetch_assoc();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Request Deletion - <?= htmlspecialchars($asset['name']) ?></title>
    <style>
        /* (Use your Tally Ho! dark theme CSS here or link your stylesheet) */
        body {
            background: linear-gradient(135deg, #1a1a1a, #2c2c2c, #3d3d3d);
            color: #eee;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding: 40px 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            background: rgba(70,70,70,0.85);
            padding: 40px;
            border-radius: 16px;
            max-width: 450px;
            width: 100%;
            box-shadow: 0 10px 25px rgba(255, 102, 0, 0.35);
            backdrop-filter: saturate(180%) blur(12px);
        }
        h2 {
            color: #ff6600;
            text-align: center;
            margin-bottom: 24px;
            font-weight: 800;
            text-shadow: 0 0 8px #ff6600;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
        }
        input[type=number], textarea {
            width: 100%;
            padding: 14px;
            border-radius: 12px;
            border: 2px solid #555;
            background: #222;
            color: #eee;
            font-size: 16px;
            margin-bottom: 20px;
            resize: vertical;
        }
        input[type=number]:focus, textarea:focus {
            outline: none;
            border-color: #ff6600;
            box-shadow: 0 0 10px #ff6600;
            background: #333;
        }
        button {
            background: transparent;
            border: 2px solid #eee;
            color: #eee;
            padding: 16px;
            width: 100%;
            border-radius: 12px;
            font-weight: 700;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s ease, box-shadow 0.3s ease, transform 0.3s ease;
        }
        button:hover {
            background-color: #ff6600;
            color: #fff;
            box-shadow: 0 0 12px #ff6600, 0 0 24px #ff6600;
            transform: translateY(-3px);
        }
        .error {
            background: #fdd;
            color: #900;
            padding: 10px 14px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 600;
            text-align: center;
        }
        a.back-link {
            display: block;
            margin-top: 24px;
            color: #ff6600;
            font-weight: 600;
            text-align: center;
            text-decoration: none;
            user-select: none;
        }
        a.back-link:hover {
            text-decoration: underline;
            color: #ff9966;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Request Deletion - <?= htmlspecialchars($asset['name']) ?></h2>
        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="POST">
            <label for="quantity">Quantity to Delete (max <?= (int)$asset['quantity'] ?>)</label>
            <input type="number" id="quantity" name="quantity" min="1" max="<?= (int)$asset['quantity'] ?>" value="1" required />
            <label for="reason">Reason for Deletion (optional)</label>
            <textarea id="reason" name="reason" rows="3" placeholder="Explain why you want to delete this asset..."></textarea>
            <button type="submit">Submit Request</button>
        </form>
        <a href="view_assets.php" class="back-link">← Back to Inventory</a>
    </div>
</body>
</html>
