<?php
include "../config.php";
session_start();
if ($_SESSION['role'] !== 'user') die("Access denied.");

$user_id = $_SESSION['user_id'];
$result = $conn->query("SELECT * FROM assets WHERE added_by=$user_id");
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Assets</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f7f9;
            color: #2c3e50;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            max-width: 1000px;
            width: 100%;
            margin: 50px auto;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
        }

        .container:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.15);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #3498db;
            font-size: 28px;
            transition: color 0.3s ease;
        }

        h2:hover {
            color: #2980b9;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px 15px;
            border: 1px solid #ddd;
            text-align: left;
            transition: background-color 0.3s ease;
        }

        th {
            background-color: #3498db;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #ecf0f1;
        }

        img {
            max-width: 80px;
            max-height: 80px;
            object-fit: cover;
            border-radius: 6px;
            transition: transform 0.3s ease;
        }

        img:hover {
            transform: scale(1.1);
        }

        a {
            color: #3498db;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        a:hover {
            color: #2980b9;
        }

        .back-btn {
            display: inline-block;
            background-color: #3498db;
            color: white;
            padding: 10px 16px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 16px;
            margin-top: 20px;
            text-align: center;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .back-btn:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
        }

        td a {
            font-size: 14px;
            padding: 6px 12px;
            background-color: #e74c3c;
            color: white;
            border-radius: 6px;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        td a:hover {
            background-color: #c0392b;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Inventory</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Quantity</th>
                <th>Image</th>
                <th>Date Added</th>
                <th>Action</th>
            </tr>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= htmlspecialchars($row['description']) ?></td>
                <td><?= (int)$row['quantity'] ?></td>
                <td>
                    <?php if (!empty($row['image_path'])): ?>
                        <img src="../<?= $row['image_path'] ?>" alt="Asset Image">
                    <?php else: ?>
                        No Image
                    <?php endif; ?>
                </td>
                <td><?= $row['date_added'] ?></td>
                <td>
                    <a href="delete_asset.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete this asset?')">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
        <br>
        <a href="dashboard.php" class="back-btn">Back to Dashboard</a>
    </div>
</body>
</html>
