<?php
include "../config.php";
session_start();
if ($_SESSION['role'] !== 'user') die("Access denied.");

$user_id = $_SESSION['user_id'];
$result = $conn->query("SELECT * FROM assets WHERE added_by=$user_id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>My Assets</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0; padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body, html {
            height: 100%;
            background: linear-gradient(135deg, #1a1a1a, #2c2c2c, #3d3d3d);
            color: #eee;
            padding: 40px 20px;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: flex-start;
        }

        .container {
            max-width: 1000px;
            width: 100%;
            background: rgba(70, 70, 70, 0.85);
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(255, 102, 0, 0.35);
            backdrop-filter: saturate(180%) blur(12px);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .container:hover {
            transform: translateY(-6px);
            box-shadow: 0 14px 40px rgba(255, 102, 0, 0.5);
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #ff6600;
            font-size: 36px;
            font-weight: 800;
            text-shadow: 0 0 10px #ff6600;
            user-select: none;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            background: #333;
            border-radius: 12px;
            overflow: hidden;
        }

        th, td {
            padding: 15px 18px;
            border-bottom: 1px solid rgba(255,255,255,0.2);
            text-align: left;
            font-size: 16px;
            color: #eee;
            text-shadow: 0 0 2px rgba(0,0,0,0.6);
            vertical-align: middle;
        }

        th {
            background-color: #444;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        tr:nth-child(even) {
            background-color: #2e2e2e;
        }

        tr:hover {
            background-color: rgba(255, 255, 255, 0.15);
            cursor: default;
            transition: background-color 0.3s ease;
        }

        img {
            max-width: 80px;
            max-height: 80px;
            object-fit: cover;
            border-radius: 8px;
            transition: transform 0.3s ease;
            user-select: none;
        }

        img:hover {
            transform: scale(1.1);
        }

        a.delete-link {
            font-size: 14px;
            padding: 10px 18px;
            background-color: transparent;
            color: #ff6600;
            border: 2px solid #ff6600;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 700;
            transition: background-color 0.3s ease, transform 0.2s ease, color 0.3s ease, box-shadow 0.3s ease;
            display: inline-block;
            user-select: none;
        }

        a.delete-link:hover {
            background-color: #ff6600;
            color: #fff;
            transform: translateY(-2px);
            box-shadow: 0 0 10px #ff6600, 0 0 20px #ff6600;
        }

        .back-btn {
            display: inline-block;
            background: transparent;
            border: 2px solid #eee;
            color: #eee;
            padding: 14px 32px;
            border-radius: 12px;
            font-size: 18px;
            font-weight: 600;
            text-decoration: none;
            margin-top: 30px;
            user-select: none;
            transition:
                background-color 0.3s ease,
                color 0.3s ease,
                box-shadow 0.3s ease,
                transform 0.3s ease;
        }

        .back-btn:hover {
            background-color: #ff6600;
            color: #fff;
            box-shadow: 0 0 12px #ff6600, 0 0 24px #ff6600;
            transform: translateY(-3px);
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Inventory</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Quantity</th>
                    <th>Image</th>
                    <th>Date Added</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['id']) ?></td>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= htmlspecialchars($row['description']) ?></td>
                    <td><?= (int)$row['quantity'] ?></td>
                    <td>
                        <?php if (!empty($row['image_path'])): ?>
                            <img src="../<?= htmlspecialchars($row['image_path']) ?>" alt="Asset Image">
                        <?php else: ?>
                            No Image
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($row['date_added']) ?></td>
                    <td>
                        <a href="request_deletion.php?id=<?= urlencode($row['id']) ?>"
                           class="delete-link"
                           onclick="return confirm('Request deletion for this asset?')">
                           Request Deletion
                        </a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <a href="dashboard.php" class="back-btn">Back to Dashboard</a>
    </div>
</body>
</html>
